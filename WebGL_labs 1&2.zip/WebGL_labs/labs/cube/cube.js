"use strict";

var canvas;
var gl;
var program;

var NumVertices = 36;

var points = []; // array that stores the points
var colors = []; // array that stores the colors

var xAxis = 0;
var yAxis = 1;
var zAxis = 2;

var axis = 0;

var cube;
var cone;
var pyramide;

// used in buttons for applying the changes on an object
var selectedObj; 

// for perspective
var near = "0.3"; // ZNear - the smaller is Z, the larger is object => its near
var far = 3.0; // ZFar - the larger is Z, the smaller the object is => it is far
var radius = 4.0; // is the rotation radius of camera, 
// because our camera is moving around the objects
var theta  = 0.0; // 
var phi    = 0.0;
var dr = 5.0 * Math.PI/180.0;

var  fovy = 45.0;  // Field-of-view in Y direction angle (in degrees)
var  aspect = 1.0; // Viewport aspect ratio

// "view matrix" is the matrix that moves everything
// the opposite of the camera effectively making 
// everything relative to the camera as though the 
// camera was at the origin (0,0,0).
var modelViewMatrix, projectionMatrix;
var modelViewMatrixLoc, projectionMatrixLoc;
var eye;
const at = vec3(0.0, 0.0, 0.0);
const up = vec3(0.0, 1.0, 0.0);

// this class sets some caracteristics of all objects
class Shape {
    constructor(color) {
        this.color = color;
        this.rotation = [0,0,0]; // [x,y,z]
        this.theta = [0,0,0];    // [x,y,z]
        this.scale = [1,1,1];    // [x,y,z]
        this.isRemoved = false;  // denotes that object in prezent on canvas
    }

    drawShape() {
        //
        //  Load shaders and initialize attribute buffers
        //
        if (this.isRemoved == true){
            return; // used in adding and removing an object on/from canvas
        } 

        var cBuffer = gl.createBuffer(); // create buffer
         // bind position buffer:
         // it is used in refering other functions to the resources 
         // thorugh the bind point
        gl.bindBuffer(gl.ARRAY_BUFFER, cBuffer); 
        // now we have to put data in that buffer
        gl.bufferData(gl.ARRAY_BUFFER, flatten(this.colorArray), gl.STATIC_DRAW);

        var vColor = gl.getAttribLocation(program, "vColor");
        gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 0, 0);
        // to take data from the buffer we turn on the attribute
        gl.enableVertexAttribArray(vColor);
        // here we specify how to pull data out
        var vBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, flatten(this.pointsArray), gl.STATIC_DRAW);

        // here is a variable that compute & set the position of the body 
        // and convert it to clip space
        // from where vertex shader will draw a triangle
        var vPosition = gl.getAttribLocation(program, "vPosition");
        gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(vPosition); // turn on the attribute

        // set rotation
        var thetaLoc = gl.getUniformLocation(program, "theta");
        this.theta[this.axis] += 2.0;
        gl.uniform3fv(thetaLoc, this.theta);
        // set translation
        var transLoc = gl.getUniformLocation(program, "translation");
        // console.log(transLoc)
        gl.uniform3fv(transLoc, this.translation);
        // set scaling
        var scaleLoc = gl.getUniformLocation(program, "scale");
        gl.uniform3fv(scaleLoc, this.scale); 
        
        gl.drawArrays(gl.TRIANGLES, 0, this.pointsArray.length);
    }
}
// create an object class that uses the Shape class with all its caracteristics
class Cube extends Shape {

    constructor(color) {
            super(color);
            this.pointsArray = [];
            this.colorArray = [];
            this.getVertexColor();
            this.translation = [-0.5,-0.5,0];

        }
        // We need to parition the quad into two triangles in order for
        // WebGL to be able to render it.  In this case, we create two
        // triangles from the quad indices

    //vertex color assigned by the index of the vertex
    getVertexColor() {
        this.quad(1, 0, 3, 2);
        this.quad(2, 3, 7, 6);
        this.quad(3, 0, 4, 7);
        this.quad(6, 5, 1, 2);
        this.quad(4, 5, 6, 7);
        this.quad(5, 4, 0, 1);
    }

    quad(a, b, c, d) { // set vertex position
        var vertices = [
            vec4(-0.5/2, -0.5/2, 0.5/2, 1.0),
            vec4(-0.5/2, 0.5/2, 0.5/2, 1.0),
            vec4(0.5/2, 0.5/2, 0.5/2, 1.0),
            vec4(0.5/2, -0.5/2, 0.5/2, 1.0),
            vec4(-0.5/2, -0.5/2, -0.5/2, 1.0),
            vec4(-0.5/2, 0.5/2, -0.5/2, 1.0),
            vec4(0.5/2, 0.5/2, -0.5/2, 1.0),
            vec4(0.5/2, -0.5/2, -0.5/2, 1.0)
        ];

        var vertexColors = [
            [0.0, 0.0, 0.0, 1.0], // black
            [1.0, 0.0, 0.0, 1.0], // red
            [1.0, 1.0, 0.0, 1.0], // yellow
            [0.0, 1.0, 0.0, 1.0], // green
            [0.0, 0.0, 1.0, 1.0], // blue
            [1.0, 0.0, 1.0, 1.0], // magenta
            [0.0, 1.0, 1.0, 1.0], // cyan
            [1.0, 1.0, 1.0, 1.0] // white
        ];

        var indices = [a, b, c, a, c, d];

        // create an array for points
        for (var i = 0; i < indices.length; ++i) {
            this.pointsArray.push(vertices[indices[i]]);
            //colors.push( vertexColors[indices[i]] );

            // for solid colored faces use
            this.colorArray.push(this.color);
        }
    }
}
    // create a class for a new object
class  Cone extends Shape {
 constructor(color, steps){
        super(color);
        this.steps = steps;
        this.pointsArray = [];
        this.colorArray = [];
        this.getVertexColor();
        this.translation = [0.5,-0.5,0];
 }
    // We need to parition the quad into two triangles in order for
    // WebGL to be able to render it.  In this case, we create two
    // triangles from the quad indices

    //vertex color assigned by the index of the vertex
    getVertexColor(){
        var baseArray = [];
        var center = [0,0,0,1];
        var peek = [0,0.5,0,1];
        var radius = 0.3;
        for (var i = 0; i < this.steps; i++) {
            var x = ( radius * Math.cos(2 * Math.PI * i / this.steps));
            var z = ( radius * Math.sin(2 * Math.PI * i / this.steps));
            baseArray.push([x,0,z,1]);
        }
        baseArray.push(baseArray[0]);
        //  put in the created array the corect order of points for 
        // drawing triangles
        for ( var i = 0; i< this.steps; i++){
            // set triangle of the cone base
            this.pointsArray.push(baseArray[i]);
            this.pointsArray.push(center);
            this.pointsArray.push(baseArray[i+1]);
            // set the pick and link it with the point on the base
            this.pointsArray.push(peek);
            this.pointsArray.push(baseArray[i]);
            this.pointsArray.push(baseArray[i+1]);
            // set color
            this.colorArray.push(this.color);
            this.colorArray.push(this.color);
            this.colorArray.push(this.color);
            this.colorArray.push([1,1,1,1]);
            this.colorArray.push(this.color);
            this.colorArray.push(this.color);
        }
    }
}
// create pyramide class using a cone
// but with less points on base 
class Pyramide extends Cone {
    constructor(color){
        super(color,4);
        this.translation = [0.3,0.3,0];  
    }
} 

window.onload = function init() {
    canvas = document.getElementById("gl-canvas");

    gl = WebGLUtils.setupWebGL(canvas);
    if (!gl) { alert("WebGL isn't available"); }
    // resize canvas to match its display size
    // using viewport we pass the current size of the canvas
    // and tell WebGL how to convert from clip space to pixels
    gl.viewport(0, 0, canvas.width, canvas.height);
    // clear canvas color
    gl.clearColor(197/255, 227/255, 252/255, 1.0);
    //  gl.clearColor(0.0, 0.0, 0.0, 1.0);
    //  gl.clearColor(1.0, 1.0, 1.0, 1.0);

    gl.enable(gl.DEPTH_TEST);

    program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program); // we tell to WebGL which shader program to execute

    // create the objects
    cube = new Cube([0.2, 0.2, 1.0, 1.0]);

   // cone = new Cone([1, 0,0,1], 50);
     cone = new Cone([1, 0,0,1], 4);

    pyramide = new Pyramide ([0.7,0.5,0.8,1]);

    // default selected object
    selectedObj = cube;

    // get uniform location for ModelViewMatrix
    modelViewMatrixLoc = gl.getUniformLocation( program, "modelViewMatrix" );
    projectionMatrixLoc = gl.getUniformLocation( program, "projectionMatrix" );

    // event listeners for buttons
    document.getElementById("selectedFigure1").onclick = function() {
       selectedObj = cube;
    };
    document.getElementById("selectedFigure2").onclick = function() {
       selectedObj = pyramide;
    };
    document.getElementById("selectedFigure3").onclick = function() {
       selectedObj = cone;
    };

    document.getElementById("xButton").onclick = function() {
        selectedObj.axis = xAxis;
    };
    document.getElementById("yButton").onclick = function() {
        selectedObj.axis = yAxis;
    };
    document.getElementById("zButton").onclick = function() {
        selectedObj.axis = zAxis;
    };

    // sliders for viewing parameters
    document.getElementById("translateX").onchange = function(event) {
        selectedObj.translation[0] = event.target.value;
    };
    document.getElementById("translateY").onchange = function(event) {
        selectedObj.translation[1] = event.target.value;
    };
    document.getElementById("translateZ").onchange = function(event) {
        selectedObj.translation[2] = event.target.value;
    };

    document.getElementById("scaleX").onchange = function(event) {
        selectedObj.scale[0] = event.target.value;
    };
    document.getElementById("scaleY").onchange = function(event) {
        selectedObj.scale[1] = event.target.value;
    };
    document.getElementById("scaleZ").onchange = function(event) {
        selectedObj.scale[2] = event.target.value;
    };

    ////////////////////////////////
    document.getElementById("addFig1").onclick = function(event){
        cube.isRemoved = false;        
    };

    document.getElementById("removeFig1").onclick = function(event){
        cube.isRemoved = true;        
    };

    ////////////////////////////////
    document.getElementById("addFig2").onclick = function(event){
        pyramide.isRemoved = false;        
    };

    document.getElementById("removeFig2").onclick = function(event){
        pyramide.isRemoved = true;     
    };

    /////////////////////////////// 
    document.getElementById("addFig3").onclick = function(event){
        cone.isRemoved = false;        
    };

    document.getElementById("removeFig3").onclick = function(event){
        cone.isRemoved = true;        
    };

   //////////////////////////////
   // sliders for viewing parameters
   document.getElementById("zFarSlider").onchange = function(event) {
        far = event.target.value;
    };
    document.getElementById("zNearSlider").onchange = function(event) {
        near = event.target.value;
    };
    document.getElementById("radiusSlider").onchange = function(event) {
        radius = event.target.value;
    };
    document.getElementById("thetaSlider").onchange = function(event) {
        theta = event.target.value* Math.PI/180.0;
    };
    document.getElementById("phiSlider").onchange = function(event) {
        phi = event.target.value* Math.PI/180.0;
    };
    document.getElementById("aspectSlider").onchange = function(event) {
        aspect = event.target.value;
    };
    document.getElementById("fovSlider").onchange = function(event) {
        fovy = event.target.value;
    };
        render();
    }

function render() {
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    // position of the camera/observer
    eye = vec3(radius*Math.sin(theta)*Math.cos(phi),
    radius*Math.sin(theta)*Math.sin(phi), radius*Math.cos(theta));
    modelViewMatrix = lookAt(eye, at , up);
    // compute projection matrix
    projectionMatrix = perspective(fovy, aspect, near, far);

    gl.uniformMatrix4fv( modelViewMatrixLoc, false, flatten(modelViewMatrix) );
    gl.uniformMatrix4fv( projectionMatrixLoc, false, flatten(projectionMatrix) );

    cube.drawShape();
    cone.drawShape();
    pyramide.drawShape();
    
    requestAnimFrame(render);
}